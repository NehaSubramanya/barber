package com.example.barberapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
